export const OPEN_NAV_MENU = 'OPEN_NAV_MENU';
export const CLOSE_NAV_MENU = 'CLOSE_NAV_MENU';
export const COLLAPSE_NAV_MENU = 'COLLAPSE_NAV_MENU';
export const CHANGE_APP = 'CHANGE_APP';
export const DEFAULT_APP = 'DEFAULT_APP';
