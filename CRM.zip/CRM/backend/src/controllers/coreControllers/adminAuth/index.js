const createAuthMiddleware = require('@/controllers/middlewaresControllers/createAuthMiddleware');
module.exports = createAuthMiddleware('Admin');
